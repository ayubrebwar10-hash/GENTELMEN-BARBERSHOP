import express from "express";
import cors from "cors";
import db from "./db.js";

const app = express();
app.use(cors());
app.use(express.json());

const PORT = 4000;
const OPEN = "13:00";
const CLOSE = "23:00";
const STEP = 30;

function makeSlots() {
  const result = [];
  for (let m = 13 * 60; m <= 22 * 60 + 30; m += STEP) {
    const h = Math.floor(m / 60);
    const min = m % 60;
    result.push(`${String(h).padStart(2,"0")}:${String(min).padStart(2,"0")}`);
  }
  return result;
}

app.get("/api/barbers", (req, res) => {
  res.json(db.prepare("SELECT * FROM barbers ORDER BY id").all());
});

app.get("/api/services", (req, res) => {
  res.json(db.prepare("SELECT * FROM services ORDER BY id").all());
});

app.get("/api/slots", (req, res) => {
  const { date, barberId } = req.query;
  if (!date || !barberId) return res.status(400).json({error:"date and barberId are required"});

  const booked = db.prepare(
    "SELECT booking_time FROM bookings WHERE booking_date=? AND barber_id=? AND status != 'cancelled'"
  ).all(date, barberId).map(x => x.booking_time);

  res.json(makeSlots().map(time => ({ time, available: !booked.includes(time) })));
});

app.post("/api/bookings", (req, res) => {
  const { customerName, phone, notes="", barberId, serviceId, date, time } = req.body;

  if (!customerName || !phone || !barberId || !serviceId || !date || !time)
    return res.status(400).json({error:"جميع الحقول الأساسية مطلوبة"});

  const barber = db.prepare("SELECT * FROM barbers WHERE id=?").get(barberId);
  const service = db.prepare("SELECT * FROM services WHERE id=?").get(serviceId);
  if (!barber || !service) return res.status(400).json({error:"الحلاق أو الخدمة غير موجودة"});

  try {
    const result = db.prepare(`
      INSERT INTO bookings
      (customer_name, phone, notes, barber_id, service_id, booking_date, booking_time)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(customerName.trim(), phone.trim(), notes.trim(), barberId, serviceId, date, time);

    res.status(201).json({
      id: result.lastInsertRowid,
      message: "تم حجز الموعد بنجاح"
    });
  } catch (e) {
    if (String(e.message).includes("UNIQUE"))
      return res.status(409).json({error:"هذا الموعد محجوز مسبقاً"});
    res.status(500).json({error:"حدث خطأ في الحجز"});
  }
});

app.get("/api/bookings", (req, res) => {
  const rows = db.prepare(`
    SELECT b.*, br.name AS barber_name, s.name AS service_name, s.price
    FROM bookings b
    JOIN barbers br ON br.id=b.barber_id
    JOIN services s ON s.id=b.service_id
    ORDER BY b.booking_date DESC, b.booking_time DESC
  `).all();
  res.json(rows);
});

app.patch("/api/bookings/:id/status", (req, res) => {
  const allowed = ["pending","confirmed","cancelled","completed"];
  const { status } = req.body;
  if (!allowed.includes(status)) return res.status(400).json({error:"حالة غير صحيحة"});
  db.prepare("UPDATE bookings SET status=? WHERE id=?").run(status, req.params.id);
  res.json({ok:true});
});

app.listen(PORT, () => console.log(`GENTLMEN API: http://localhost:${PORT}`));
