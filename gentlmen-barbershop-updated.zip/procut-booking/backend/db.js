import Database from "better-sqlite3";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });

const db = new Database(path.join(dataDir, "procut.sqlite"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS barbers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  price INTEGER NOT NULL DEFAULT 25000,
  image TEXT DEFAULT '',
  rating REAL NOT NULL DEFAULT 5
);

CREATE TABLE IF NOT EXISTS services (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  price INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  notes TEXT DEFAULT '',
  barber_id INTEGER NOT NULL,
  service_id INTEGER NOT NULL,
  booking_date TEXT NOT NULL,
  booking_time TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(barber_id, booking_date, booking_time),
  FOREIGN KEY(barber_id) REFERENCES barbers(id),
  FOREIGN KEY(service_id) REFERENCES services(id)
);
`);

try { db.exec("ALTER TABLE barbers ADD COLUMN rating REAL NOT NULL DEFAULT 5"); } catch {}

const barberCount = db.prepare("SELECT COUNT(*) AS c FROM barbers").get().c;
if (!barberCount) {
  const add = db.prepare("INSERT INTO barbers (name, price, image, rating) VALUES (?, ?, ?, ?)");
  add.run("ممود", 25000, "/mahmood.jpg", 5.0);
  add.run("أيوب", 25000, "/ayoub.jpg", 5.0);
  add.run("حسون", 25000, "/hasson.jpg", 4.8);
  add.run("عبود", 25000, "/aboud.jpg", 0);
}
const serviceCount = db.prepare("SELECT COUNT(*) AS c FROM services").get().c;
if (!serviceCount) {
  const add = db.prepare("INSERT INTO services (name, price) VALUES (?, ?)");
  add.run("قصة شعر كاملة", 25000);
  add.run("تدريج", 20000);
  add.run("لحية", 15000);
  add.run("شعر + لحية", 35000);
}

export default db;
