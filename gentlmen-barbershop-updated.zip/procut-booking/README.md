# GENTLMEN — نظام حجز صالون/حلاق

مشروع جاهز مستوحى من تدفق الموقع الظاهر في التسجيل:
الرئيسية → اختيار الحلاق → اختيار التاريخ والوقت → بيانات الزبون → تأكيد الحجز.

## التقنية
- Frontend: React + Vite
- Backend: Node.js + Express
- Database: SQLite
- RTL / Arabic + English button
- تصميم متجاوب للموبايل

## التشغيل

### 1) المتطلبات
Node.js 18 أو أحدث.

### 2) تشغيل الخادم
```bash
cd backend
npm install
npm run dev
```

الخادم يعمل على:
http://localhost:4000

### 3) تشغيل الواجهة
في نافذة Terminal ثانية:
```bash
cd frontend
npm install
npm run dev
```

ثم افتح:
http://localhost:5173

قاعدة البيانات يتم إنشاؤها تلقائياً داخل:
backend/data/procut.sqlite

## API
GET  /api/barbers
GET  /api/services
GET  /api/slots?date=YYYY-MM-DD&barberId=1
POST /api/bookings
GET  /api/bookings
PATCH /api/bookings/:id/status

> قبل النشر الفعلي أضف تسجيل دخول للإدارة، حماية API، والتحقق من رقم الهاتف.

## الحلاقون
- ممود — ⭐ 5.0
- أيوب — ⭐ 5.0
- حسون — ⭐ 4.8
- عبود — تقييم جديد

تم تضمين الصور واللوغو داخل `frontend/public`.

## عنوان المحل
شارع القدس — مجمع گرين — الطابق الثاني

## الأسعار
- شعر ولحية — 15,000 دينار
- شعر — 10,000 دينار
- تحديد — 5,000 دينار
- تنظيف بشرة — 25,000 دينار
- تحديد + شسوار — 10,000 دينار
