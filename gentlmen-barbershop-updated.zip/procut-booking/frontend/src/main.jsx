import React, { useState, useEffect } from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

const services = [
  { name: "شعر ولحية", price: 15000 },
  { name: "شعر", price: 10000 },
  { name: "تحديد", price: 5000 },
  { name: "تنظيف بشرة", price: 25000 },
  { name: "تحديد + شسوار", price: 10000 },
];
const API = "http://localhost:4000/api";

const money = n => new Intl.NumberFormat("ar-IQ").format(n) + " د.ع";

function Header() {
  return (
    <header className="header">
      <button className="outline">EN</button>
      <img className="brandLogo" src="/logo.jpeg" alt="Gentlemen's Barbershop" />
      <button className="menu">☰</button>
    </header>
  );
}

function Home({ onBook }) {
  return (
    <>
      <section className="hero">
        <Header />
        <div className="heroBg"/>
        <div className="heroContent">
          <img className="heroLogo" src="/logo.jpeg" alt="Gentlemen's Barbershop" />
          <div className="line"/>
          <p>دقة الحلاقة · فخامة التفاصيل</p>
          <button className="goldBtn" onClick={onBook}>احجز الآن</button>
        </div>
        <div className="scroll">مرر للأسفل</div>
      </section>

      <section className="about container">
        <h2>نحن</h2>
        <p>
          في GENTLMEN نهتم بكل تفصيل من أجواء المركز وطريقة الاستقبال
          وراحة الزبون إلى كل لمسة حتى يكون وقتك وزيارتك مميزة من البداية للنهاية.
          هدفنا أن نقدم خدمة تليق بك.
        </p>
        <div className="address">📍 شارع القدس — مجمع گرين — الطابق الثاني</div>
        <h2>الحلاقون</h2>
        <div className="homeBarbers">
          {[
            ["/mahmood.jpg","ممود","5.0"],
            ["/ayoub.jpg","أيوب","5.0"],
            ["/hasson.jpg","حسون","4.8"],
            ["/aboud.jpg","عبود","جديد"]
          ].map(([img,name,rating]) => (
            <div className="homeBarber" key={name}>
              <img src={img} alt={name}/>
              <div><b>{name}</b><span>{rating !== "جديد" ? `★ ${rating}` : "تقييم جديد"}</span></div>
            </div>
          ))}
        </div>
      </section>

      <footer>
        <b>GENTLMEN</b>
        <p>دقة الحلاقة · فخامة التفاصيل</p>
        <p>بغداد · المنصور · الداوودي · شارع الساعة</p>
        <p>الدوام يومياً: 1:00 ظهراً - 11:00 مساءً</p>
      </footer>
    </>
  );
}

function Progress({ step }) {
  return <div className="progress">
    {[1,2,3,4].map(n => <span className={n <= step ? "active" : ""} key={n}/>)}
  </div>;
}

function Booking({ onBack }) {
  const [step, setStep] = useState(1);
  const [barbers, setBarbers] = useState([]);
  const [services, setServices] = useState([]);
  const [slots, setSlots] = useState([]);
  const [data, setData] = useState({
    barberId:"", serviceId:"", date:new Date().toISOString().slice(0,10),
    time:"", customerName:"", phone:"", notes:""
  });
  const [message, setMessage] = useState("");

  useEffect(() => {
    Promise.all([
      fetch(`${API}/barbers`).then(r=>r.json()),
      fetch(`${API}/services`).then(r=>r.json())
    ]).then(([b,s]) => { setBarbers(b); setServices(s); });
  }, []);

  useEffect(() => {
    if (data.date && data.barberId) {
      fetch(`${API}/slots?date=${data.date}&barberId=${data.barberId}`)
        .then(r=>r.json()).then(setSlots);
    }
  }, [data.date, data.barberId]);

  const barber = barbers.find(x => String(x.id) === String(data.barberId));
  const service = services.find(x => String(x.id) === String(data.serviceId));

  const next = () => {
    setMessage("");
    if (step === 1 && !data.barberId) return setMessage("اختر الحلاق أولاً");
    if (step === 2 && (!data.date || !data.time)) return setMessage("اختر اليوم والوقت");
    if (step === 3 && (!data.customerName || !data.phone)) return setMessage("أدخل الاسم ورقم الهاتف");
    setStep(s => Math.min(4, s+1));
  };

  const submit = async () => {
    const r = await fetch(`${API}/bookings`, {
      method:"POST", headers:{"Content-Type":"application/json"},
      body: JSON.stringify(data)
    });
    const json = await r.json();
    if (!r.ok) return setMessage(json.error || "تعذر الحجز");
    setStep(5);
  };

  if (step === 5) return (
    <main className="bookingPage">
      <Header/><div className="success">
        <div className="check">✓</div>
        <h1>تم حجز موعدك بنجاح</h1>
        <p>نتشرف بزيارتك في GENTLMEN</p>
        <button className="goldBtn" onClick={onBack}>العودة للرئيسية</button>
      </div>
    </main>
  );

  return (
    <main className="bookingPage">
      <Header/>
      <div className="container booking">
        <h1>احجز موعدك</h1>
        <Progress step={step}/>

        {step === 1 && <section>
          <h2>اختر الحلاق</h2>
          <div className="cards">
            {barbers.map(b => (
              <button className={"barberCard " + (String(data.barberId)===String(b.id)?"selected":"")}
                onClick={()=>setData({...data,barberId:b.id})} key={b.id}>
                <img src={b.image} />
                <span>{b.name}</span><strong>{Number(b.rating) > 0 ? `★ ${Number(b.rating).toFixed(1)}` : "تقييم جديد"}</strong>
              </button>
            ))}
          </div>
        </section>}

        {step === 2 && <section>
          <h2>اختر اليوم والوقت</h2>
          <input className="input" type="date" value={data.date}
            onChange={e=>setData({...data,date:e.target.value,time:""})}/>
          <div className="slots">
            {slots.map(s => <button disabled={!s.available}
              className={data.time===s.time?"slot selected":"slot"} key={s.time}
              onClick={()=>setData({...data,time:s.time})}>{s.time}</button>)}
          </div>
        </section>}

        {step === 3 && <section>
          <h2>بياناتك</h2>
          <label>الاسم الكامل</label>
          <input className="input" placeholder="مثال: أحمد محمد"
            value={data.customerName} onChange={e=>setData({...data,customerName:e.target.value})}/>
          <label>رقم الهاتف</label>
          <input className="input" dir="ltr" placeholder="07XX XXX XXXX"
            value={data.phone} onChange={e=>setData({...data,phone:e.target.value})}/>
          <label>ملاحظات (اختياري)</label>
          <textarea className="input" placeholder="أي تفاصيل إضافية..."
            value={data.notes} onChange={e=>setData({...data,notes:e.target.value})}/>
        </section>}

        {step === 4 && <section>
          <h2>تأكيد الحجز</h2>
          <div className="summary">
            <p><small>الخدمة</small>{service?.name || "—"}</p>
            <p><small>الحلاق</small>{barber?.name || "—"}</p>
            <p><small>الموعد</small>{data.date} — {data.time}</p>
            <p><small>الاسم</small>{data.customerName}</p>
            <p><small>السعر</small>{money(service?.price || barber?.price || 0)}</p>
          </div>
        </section>}

        {message && <div className="error">{message}</div>}

        <div className="actions">
          <button className="backBtn" onClick={()=>step===1?onBack():setStep(s=>s-1)}>رجوع</button>
          {step < 4
            ? <button className="goldBtn" onClick={next}>التالي</button>
            : <button className="goldBtn" onClick={submit}>تأكيد الحجز</button>}
        </div>
      </div>
    </main>
  );
}

function Admin() {
  const [rows,setRows]=useState([]);
  const load=()=>fetch(`${API}/bookings`).then(r=>r.json()).then(setRows);
  useEffect(load,[]);
  const status = async (id,s) => {
    await fetch(`${API}/bookings/${id}/status`, {
      method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({status:s})
    }); load();
  };
  return <div className="admin container">
    <Header/><h1>لوحة الحجوزات</h1>
    <div className="tableWrap"><table><thead><tr>
      <th>الزبون</th><th>الهاتف</th><th>الخدمة</th><th>الحلاق</th><th>الموعد</th><th>الحالة</th><th>إجراء</th>
    </tr></thead><tbody>
      {rows.map(r=><tr key={r.id}>
        <td>{r.customer_name}</td><td dir="ltr">{r.phone}</td><td>{r.service_name}</td>
        <td>{r.barber_name}</td><td>{r.booking_date} {r.booking_time}</td>
        <td>{r.status}</td>
        <td><button onClick={()=>status(r.id,"confirmed")}>تأكيد</button>
        <button onClick={()=>status(r.id,"cancelled")}>إلغاء</button></td>
      </tr>)}
    </tbody></table></div>
  </div>
}

function App() {
  const [page,setPage]=useState(location.hash==="#admin"?"admin":"home");
  useEffect(()=>{const f=()=>setPage(location.hash==="#admin"?"admin":location.hash==="#book"?"book":"home"); addEventListener("hashchange",f); return()=>removeEventListener("hashchange",f)},[]);
  if(page==="admin") return <Admin/>;
  if(page==="book") return <Booking onBack={()=>location.hash=""}/>;
  return <Home onBook={()=>location.hash="book"}/>;
}
createRoot(document.getElementById("root")).render(<App/>);
